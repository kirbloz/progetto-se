package it.unibs.fp.myutils;

public class MyMath {

	public static double logBaseGenerica(double base, double x) {
		return Math.log(x) / Math.log(base);
	}
	
	
	
}
