package it.unibs.fp.myutils;

/**
 * Rappresenta i giorni della settimana, con nomi e indici
 * 
 * @author Wade Giovanni Baisini (735655)
 *
 */
public enum Settimana {

	LUNEDI("Lunedi'"), MARTEDI("Martedi'"), MERCOLEDI("Mercoledi'"), GIOVEDI("Giovedi'"), VENERDI("Venerdi'"),
	SABATO("Sabato"), DOMENICA("Domenica");

	private final String nome;
	//private final int indice; //si ricava semplicemente come ordinal()+1

	Settimana(String name) {
		this.nome = name;
	}

	public String getNome() {
		return this.nome;
	}

	/**
	 * Restituisce il numero che indica il giorno all'interno della settimana
	 * @return indice intero
	 */
	public int getIndice() {
		return this.ordinal()+1;
	}

	/**
	 * Ritorna una stringa contenente le informazioni di tutti i valori della classe
	 * 
	 * @return String formattata
	 */
	public static String printAll() {
		StringBuilder desc = new StringBuilder();
		for (Settimana giorno : Settimana.values()) {
			desc.append(giorno.toString());
			desc.append("\n");
		}
		return desc.toString();
	}

	@Override
	public String toString(){
		return String.format("[%d] %s", this.ordinal()+1, this.getNome());
	}
}
